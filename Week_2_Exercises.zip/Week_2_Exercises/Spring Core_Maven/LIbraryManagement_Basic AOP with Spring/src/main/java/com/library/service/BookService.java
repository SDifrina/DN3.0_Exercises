package com.library.service;
import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class BookService 
{
    private BookRepository bookRepository;
    public BookService(BookRepository bookRepository) 
    {
        this.bookRepository = bookRepository;
    }
    @Autowired
    public void setBookRepository(BookRepository bookRepository) 
    {
        this.bookRepository = bookRepository;
    }
    public void addBook(String book) 
    {
        if (bookRepository != null) 
        {
            bookRepository.addBook(book);
        } 
        else 
        {
            System.out.println("BookRepository is not initialized");
        }
    }
    public void printAllBooks() 
    {
        if (bookRepository != null) 
        {
            List<String> books = bookRepository.getAllBooks();
            if (books.isEmpty()) 
            {
                System.out.println("No books found in the repository.");
            } 
            else 
            {
                System.out.println("Books in the repository:");
                for (String book : books) 
                {
                    System.out.println(book);
                }
            }
        } 
    }
}
