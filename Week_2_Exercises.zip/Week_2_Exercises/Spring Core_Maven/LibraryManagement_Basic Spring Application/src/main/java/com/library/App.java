package com.library;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;
import com.library.repository.BookRepository;
public class App 
{
    public static void main(String[] args) 
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        BookRepository bookRepository = (BookRepository) context.getBean("bookRepository");
        BookService bookService = (BookService) context.getBean("bookService");
        bookService.setBookRepository(bookRepository);
        
        bookService.addBook("Tangled");
        bookService.addBook("Snow White");
        bookService.addBook("Beauty and Beast");
        System.out.println("Books in the repository:");
        bookService.getAllBooks();
    }
}
