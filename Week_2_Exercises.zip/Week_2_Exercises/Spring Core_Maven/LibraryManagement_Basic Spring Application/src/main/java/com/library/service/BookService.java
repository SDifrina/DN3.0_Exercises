package com.library.service;
import java.util.*;
import com.library.repository.BookRepository;
public class BookService 
{
    private BookRepository bookRepository;
    public void setBookRepository(BookRepository bookRepository) 
    {
        this.bookRepository = bookRepository;
    }
    public void addBook(String book) 
    {
        if (bookRepository != null) 
        {
            bookRepository.addBook(book);
        } 
        else 
        {
            System.out.println("BookRepository is not initialized");
        }
    }
    public void getAllBooks() 
    {
        if (bookRepository != null) 
        {
            bookRepository.getAllBooks();
        } 
        else 
        {
            System.out.println("BookRepository is not initialized");
        }
    }
}
