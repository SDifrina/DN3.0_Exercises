package com.library.repository;
import java.util.*;
public class BookRepository 
{
    private List<String> books;
    public BookRepository() 
    {
        books = new ArrayList<>();
    }
    public void addBook(String book)
    {
        books.add(book);
    }
    public List<String> getAllBooks() 
    {
        return new ArrayList<>(books);
    }
}
