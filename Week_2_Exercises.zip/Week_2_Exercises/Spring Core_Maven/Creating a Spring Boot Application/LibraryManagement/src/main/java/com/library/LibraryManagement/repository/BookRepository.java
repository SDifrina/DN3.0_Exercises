package com.library.LibraryManagement.repository;
import com.library.LibraryManagement.book.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> 
{
}
