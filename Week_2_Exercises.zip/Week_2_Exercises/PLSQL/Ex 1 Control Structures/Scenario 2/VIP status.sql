BEGIN
    FOR customer IN (
        SELECT CustomerID, Balance
        FROM Customers
        WHERE Balance >= 10000
    ) LOOP
        UPDATE Customers
        SET IsVIP = 'YES'
        WHERE CustomerID = customer.CustomerID;

        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || customer.CustomerID || ' - Promoted to VIP.');
    END LOOP;

    COMMIT;
END;
/
