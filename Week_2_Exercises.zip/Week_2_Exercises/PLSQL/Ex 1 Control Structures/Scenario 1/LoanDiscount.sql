BEGIN
    FOR customer IN (
        SELECT c.CustomerID
        FROM Customers c
        JOIN Loans l ON c.CustomerID = l.CustomerID
        WHERE TRUNC(MONTHS_BETWEEN(SYSDATE, c.DOB) / 12) >= 60
    ) LOOP
        UPDATE Loans
        SET InterestRate = InterestRate-1
        WHERE CustomerID = customer.CustomerID;
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || customer.CustomerID || ' - Interest Rate updated.');
    END LOOP;
    COMMIT;
END;
