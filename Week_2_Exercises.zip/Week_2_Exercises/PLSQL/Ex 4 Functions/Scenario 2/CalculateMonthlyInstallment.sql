 CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
    p_LoanAmount NUMBER,
    p_AnnualInterestRate NUMBER,
    p_LoanDurationYears NUMBER
) RETURN NUMBER
IS
    v_MonthlyInterestRate NUMBER;
    v_TotalPayments NUMBER;
    v_MonthlyPayment NUMBER;
BEGIN
    v_MonthlyInterestRate := p_AnnualInterestRate / 12 / 100;
    v_TotalPayments := p_LoanDurationYears * 12;
    v_MonthlyPayment := p_LoanAmount * v_MonthlyInterestRate * POWER(1 + v_MonthlyInterestRate, v_TotalPayments) / (POWER(1 + v_MonthlyInterestRate, v_TotalPayments) - 1);
    RETURN ROUND(v_MonthlyPayment, 2);
    END CalculateMonthlyInstallment;
/
