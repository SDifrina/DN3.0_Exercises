CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_EmployeeID IN NUMBER,
    p_Percentage IN NUMBER
) AS
    v_CurrentSalary NUMBER;
BEGIN
    SELECT Salary INTO v_CurrentSalary 
    FROM Employees 
    WHERE EmployeeID = p_EmployeeID;
    UPDATE Employees
    SET Salary = Salary + (Salary * p_Percentage / 100)
    WHERE EmployeeID = p_EmployeeID;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Salary updated for Employee ID ' || p_EmployeeID || ' by ' || p_Percentage || '%.');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DECLARE
                v_ErrorMessage VARCHAR2(4000);
        BEGIN
            v_ErrorMessage := 'Employee ID ' || p_EmployeeID || ' does not exist.';
            INSERT INTO ErrorLog (ErrorID, ErrorMessage, ErrorDate)
            VALUES (ErrorLog_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
            DBMS_OUTPUT.PUT_LINE('Error: ' || v_ErrorMessage);
        END;
    WHEN OTHERS THEN
        DECLARE
            v_ErrorMessage VARCHAR2(4000);
        BEGIN
            v_ErrorMessage := SQLERRM;
            INSERT INTO ErrorLog (ErrorID, ErrorMessage, ErrorDate)
            VALUES (ErrorLog_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
            DBMS_OUTPUT.PUT_LINE('Error during salary update: ' || v_ErrorMessage);
        END;
END UpdateSalary;
/
