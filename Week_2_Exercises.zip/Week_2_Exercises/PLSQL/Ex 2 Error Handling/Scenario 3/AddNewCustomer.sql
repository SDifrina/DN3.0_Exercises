CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_CustomerID IN NUMBER,
    p_Name IN VARCHAR2,
    p_DOB IN DATE,
    p_Balance IN NUMBER
) AS
    v_CustomerCount NUMBER;
BEGIN
    BEGIN
        SELECT COUNT(*) INTO v_CustomerCount
        FROM Customers
        WHERE CustomerID = p_CustomerID;
        IF v_CustomerCount > 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'Customer with ID ' || p_CustomerID || ' already exists.');
        END IF;
        INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
        VALUES (p_CustomerID, p_Name, p_DOB, p_Balance, SYSDATE);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Customer added successfully with ID ' || p_CustomerID || '.');
    EXCEPTION
        WHEN OTHERS THEN
            DECLARE
                v_ErrorMessage VARCHAR2(4000);
            BEGIN
                IF SQLCODE = -20002 THEN
                    v_ErrorMessage := 'Customer with ID ' || p_CustomerID || ' already exists.';
                ELSE
                    v_ErrorMessage := SQLERRM;
                END IF;
                INSERT INTO ErrorLog (ErrorID, ErrorMessage, ErrorDate)
                VALUES (ErrorLog_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
                DBMS_OUTPUT.PUT_LINE('Error in adding customer: ' || v_ErrorMessage);
            END;
    END;
END AddNewCustomer;
/
