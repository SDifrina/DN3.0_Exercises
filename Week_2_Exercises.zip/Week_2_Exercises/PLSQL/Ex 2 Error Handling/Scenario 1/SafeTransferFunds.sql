create or replace PROCEDURE SafeTransferFunds (
    p_SourceAccountID IN NUMBER,
    p_TargetAccountID IN NUMBER,
    p_Amount IN NUMBER
) AS
    v_SourceBalance NUMBER;
BEGIN
    SELECT Balance INTO v_SourceBalance 
    FROM Accounts 
    WHERE AccountID = p_SourceAccountID;
    IF v_SourceBalance < p_Amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account.');
    END IF;
    UPDATE Accounts
    SET Balance = Balance - p_Amount,
        LastModified = SYSDATE
    WHERE AccountID = p_SourceAccountID;
    UPDATE Accounts
    SET Balance = Balance + p_Amount,
        LastModified = SYSDATE
    WHERE AccountID = p_TargetAccountID;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Transfer successful from Account ' || p_SourceAccountID || ' to Account ' || p_TargetAccountID || ' for amount ' || p_Amount || '.');
EXCEPTION
    WHEN OTHERS THEN
        DECLARE
            v_ErrorMessage VARCHAR2(4000);
        BEGIN
            IF SQLCODE = -20001 THEN
                v_ErrorMessage := 'Insufficient funds in the source account.';
            ELSE
                v_ErrorMessage := SQLERRM;
            END IF;
            INSERT INTO ErrorLog (ErrorID, ErrorMessage, ErrorDate)
            VALUES (ErrorLog_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
            DBMS_OUTPUT.PUT_LINE('Error in transfer: ' || v_ErrorMessage);
        END;
END SafeTransferFunds;
/
