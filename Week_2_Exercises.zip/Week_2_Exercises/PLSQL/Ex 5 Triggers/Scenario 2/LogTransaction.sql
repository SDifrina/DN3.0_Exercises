CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (
        AuditLogID, 
        TransactionID, 
        AccountID, 
        TransactionDate, 
        Amount, 
        TransactionType, 
        AuditTimestamp
    ) VALUES (
        AuditLog_SEQ.NEXTVAL, 
        :NEW.TransactionID, 
        :NEW.AccountID, 
        :NEW.TransactionDate, 
        :NEW.Amount, 
        :NEW.TransactionType, 
        SYSDATE
    );
END LogTransaction;
/
