CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest AS
    v_InterestRate CONSTANT NUMBER := 0.01;
BEGIN
    UPDATE Accounts
    SET Balance = Balance + (Balance * v_InterestRate),
        LastModified = SYSDATE
    WHERE AccountType = 'Savings';
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Monthly interest applied to all savings accounts.');
EXCEPTION
    WHEN OTHERS THEN
        DECLARE
            v_ErrorMessage VARCHAR2(4000);
        BEGIN
            v_ErrorMessage := SQLERRM;
            INSERT INTO ErrorLog (ErrorID, ErrorMessage, ErrorDate)
            VALUES (ErrorLog_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
            DBMS_OUTPUT.PUT_LINE('Error in processing monthly interest: ' || v_ErrorMessage);
        END;
END ProcessMonthlyInterest;
/
