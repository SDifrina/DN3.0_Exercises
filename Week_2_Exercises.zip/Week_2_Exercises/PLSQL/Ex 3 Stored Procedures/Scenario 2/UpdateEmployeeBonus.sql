CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_Department IN VARCHAR2,
    p_BonusPercentage IN NUMBER
) AS
BEGIN
    UPDATE Employees
    SET Salary = Salary + (Salary * p_BonusPercentage / 100)
    WHERE Department = p_Department;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Bonus of ' || p_BonusPercentage || '% applied to all employees in department ' || p_Department || '.');
EXCEPTION
    WHEN OTHERS THEN
        DECLARE
            v_ErrorMessage VARCHAR2(4000);
        BEGIN
            v_ErrorMessage := SQLERRM;
            INSERT INTO ErrorLog (ErrorID, ErrorMessage, ErrorDate)
            VALUES (ErrorLog_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
            DBMS_OUTPUT.PUT_LINE('Error in updating employee bonus: ' || v_ErrorMessage);
        END;
END UpdateEmployeeBonus;
/
