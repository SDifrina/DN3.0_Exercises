DECLARE
    CURSOR ApplyAnnualFee IS
        SELECT AccountID, Balance
        FROM Accounts;
    v_AccountID Accounts.AccountID%TYPE;
    v_Balance Accounts.Balance%TYPE;
    v_AnnualFee NUMBER := 150; 
BEGIN
    OPEN ApplyAnnualFee;
    LOOP
        FETCH ApplyAnnualFee INTO v_AccountID, v_Balance;
        EXIT WHEN ApplyAnnualFee%NOTFOUND;
        UPDATE Accounts
        SET Balance = Balance - v_AnnualFee,
            LastModified = SYSDATE
        WHERE AccountID = v_AccountID;
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || v_AccountID || ' Balance after Annual Fee Deduction ' || (v_Balance - v_AnnualFee));
    END LOOP;
    CLOSE ApplyAnnualFee;
    COMMIT;
END;
/
