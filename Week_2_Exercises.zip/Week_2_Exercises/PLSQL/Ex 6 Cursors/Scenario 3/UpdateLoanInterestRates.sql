DECLARE
    CURSOR UpdateLoanInterestRates IS
        SELECT LoanID, InterestRate
        FROM Loans;
    v_LoanID Loans.LoanID%TYPE;
    v_InterestRate Loans.InterestRate%TYPE;
    v_NewInterestRate NUMBER;
    FUNCTION CalculateNewInterestRate(oldRate NUMBER) RETURN NUMBER IS
    BEGIN
        RETURN oldRate + 1;
    END CalculateNewInterestRate;
BEGIN
    OPEN UpdateLoanInterestRates;
    LOOP
        FETCH UpdateLoanInterestRates INTO v_LoanID, v_InterestRate;
        EXIT WHEN UpdateLoanInterestRates%NOTFOUND;
        v_NewInterestRate := CalculateNewInterestRate(v_InterestRate);
        UPDATE Loans
        SET InterestRate = v_NewInterestRate
        WHERE LoanID = v_LoanID;
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || v_LoanID || ' - New Interest Rate: ' || v_NewInterestRate);
    END LOOP;
    CLOSE UpdateLoanInterestRates;
    COMMIT;
END;
/
