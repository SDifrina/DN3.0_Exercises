DECLARE
    CURSOR GenerateMonthlyStatements IS
        SELECT 
            c.CustomerID,
            c.Name AS CustomerName,
            t.AccountID,
            t.TransactionDate,
            t.Amount,
            t.TransactionType
        FROM 
            Customers c
            JOIN Accounts a ON c.CustomerID = a.CustomerID
            JOIN Transactions t ON a.AccountID = t.AccountID
        WHERE 
            t.TransactionDate BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(SYSDATE)
        ORDER BY 
            c.CustomerID, t.TransactionDate;
    v_CustomerID Customers.CustomerID%TYPE;
    v_CustomerName Customers.Name%TYPE;
    v_AccountID Transactions.AccountID%TYPE;
    v_TransactionDate Transactions.TransactionDate%TYPE;
    v_Amount Transactions.Amount%TYPE;
    v_TransactionType Transactions.TransactionType%TYPE;

    v_CurrentCustomerID Customers.CustomerID%TYPE := NULL;
    v_TotalDeposit NUMBER := 0;
   v_TotalWithdrawal NUMBER := 0;
    v_OpeningBalance NUMBER := 0;
    v_ClosingBalance NUMBER := 0;
    v_Statement VARCHAR2(1000);
BEGIN
    OPEN GenerateMonthlyStatements;
    LOOP
        FETCH GenerateMonthlyStatements INTO v_CustomerID, v_CustomerName, v_AccountID, v_TransactionDate, v_Amount, v_TransactionType;
        EXIT WHEN GenerateMonthlyStatements%NOTFOUND;
        IF v_CurrentCustomerID IS NULL OR v_CurrentCustomerID != v_CustomerID THEN
            IF v_CurrentCustomerID IS NOT NULL THEN
                DBMS_OUTPUT.PUT_LINE('Customer: ' || v_CurrentCustomerID || ' - ' || v_CustomerName);
                DBMS_OUTPUT.PUT_LINE('Total Deposit: ' || v_TotalDeposit);
                DBMS_OUTPUT.PUT_LINE('Total Withdrawal: ' ||v_TotalWithdrawal);
                DBMS_OUTPUT.PUT_LINE('Opening Balance: ' || v_OpeningBalance);
                DBMS_OUTPUT.PUT_LINE('Closing Balance: ' || v_ClosingBalance);
                DBMS_OUTPUT.PUT_LINE('-------------------------');
            END IF;
            v_CurrentCustomerID := v_CustomerID;
            v_TotalDeposit := 0;
           v_TotalWithdrawal := 0;
            SELECT Balance INTO v_OpeningBalance
            FROM Accounts
            WHERE CustomerID = v_CustomerID
            AND AccountID = v_AccountID;
            v_ClosingBalance := v_OpeningBalance;
        END IF;
        IF v_TransactionType = 'Deposit' THEN
            v_TotalDeposit := v_TotalDeposit + v_Amount;
            v_ClosingBalance := v_ClosingBalance + v_Amount;
        ELSIF v_TransactionType = 'Withdrawal' THEN
           v_TotalWithdrawal :=v_TotalWithdrawal + v_Amount;
            v_ClosingBalance := v_ClosingBalance - v_Amount;
        END IF;
    END LOOP;
    IF v_CurrentCustomerID IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Customer: ' || v_CurrentCustomerID || ' - ' || v_CustomerName);
        DBMS_OUTPUT.PUT_LINE('Total Deposit: ' || v_TotalDeposit);
        DBMS_OUTPUT.PUT_LINE('Total Withdrawal: ' ||v_TotalWithdrawal);
        DBMS_OUTPUT.PUT_LINE('Opening Balance: ' || v_OpeningBalance);
        DBMS_OUTPUT.PUT_LINE('Closing Balance: ' || v_ClosingBalance);
        DBMS_OUTPUT.PUT_LINE('-------------------------');
    END IF;
    CLOSE GenerateMonthlyStatements;
END;
/
