public class ProxyPatternTest
{
    public static void main(String[] args)
    {
        Image img = new ProxyImage("image1.jpg");
        img.display();
        System.out.println("");

        img.display();
        System.out.println("");
    }
}
