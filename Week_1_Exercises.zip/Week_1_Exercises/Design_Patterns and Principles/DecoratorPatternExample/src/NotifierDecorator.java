public abstract class NotifierDecorator implements Notifier
{
    protected Notifier notify;
    public NotifierDecorator(Notifier notify)
    {
        this.notify = notify;
    }
    public void send(String message)
    {
        notify.send(message);
    }
}