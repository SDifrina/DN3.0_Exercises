public class DecoratorPatternTest
{
    public static void main(String[] args)
    {
        Notifier notifier = new EmailNotifier();
        notifier.send("Hi, you have an email notification.");

        Notifier smsNotifier = new SMSNotifierDecorator(notifier);
        smsNotifier.send("Hello, this is to notify that you have an email and SMS notification.");

        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);
        slackNotifier.send("Hi, you have recieved an email, SMS and Slack notification.");
    }
}