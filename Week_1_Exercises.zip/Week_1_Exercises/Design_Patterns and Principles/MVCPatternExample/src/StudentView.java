public class StudentView
{
    public void displayStudentDetails(String Name, String Id, String Grade)
    {
        System.out.println("Student:");
        System.out.println("Name: " + Name);
        System.out.println("ID: " + Id);
        System.out.println("Grade: " + Grade);
    }
}
