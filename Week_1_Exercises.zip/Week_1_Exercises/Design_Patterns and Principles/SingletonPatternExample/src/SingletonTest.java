public class SingletonTest
{
    public static void main(String[] args)
    {
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        Logger logger3 = Logger.getInstance();

        logger1.logMessage("Log message from logger1.");
        logger2.logMessage("Log message from logger2.");
        logger3.logMessage("Log message from logger3.");

        boolean isSameInstance = (logger1 == logger2) && (logger2 == logger3);
        if (isSameInstance)
        {
            System.out.println("All logger instances are the same.");
        }
        else
        {
            System.out.println("Different logger instances exist.");
        }
    }
}
