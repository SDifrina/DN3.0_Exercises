public class BuilderPatternTest
{
    public static void main(String[] args)
    {
        Computer basicComputer = new Computer.Builder("Intel i3", "8GB").setStorage("500GB HDD").setWiFiEnabled(true).build();
        System.out.println("Basic Computer" +basicComputer);

        Computer gamingComputer = new Computer.Builder("Intel i7", "16GB").setStorage("1TB SSD").setGraphicsCard("NVIDIA RTX 3060 ").setWiFiEnabled(true).build();
        System.out.println("Gaming Computer" +gamingComputer);
    }
}
