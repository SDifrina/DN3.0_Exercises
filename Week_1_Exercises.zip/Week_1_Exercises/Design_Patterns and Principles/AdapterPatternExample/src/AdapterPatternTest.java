public class AdapterPatternTest
{
    public static void main(String[] args)
    {
        PaymentProcessor gpayProcessor = new GPayAdapter(new GPay());
        gpayProcessor.processPayment(1500.00);

        PaymentProcessor paytmProcessor = new PaytmAdapter(new Paytm());
        paytmProcessor.processPayment(250.00);

        PaymentProcessor phonePeProcessor = new PhonePeAdapter(new PhonePe());
        phonePeProcessor.processPayment(50.00);
    }
}
