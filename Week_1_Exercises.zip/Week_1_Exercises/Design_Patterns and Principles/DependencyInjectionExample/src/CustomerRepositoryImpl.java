public class CustomerRepositoryImpl implements CustomerRepository
{
    public Customer findCustomerById(String customerId)
    {
        return new Customer(customerId, "Difrina");
    }
}