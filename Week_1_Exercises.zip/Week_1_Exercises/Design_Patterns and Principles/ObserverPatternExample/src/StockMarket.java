import java.util.*;
public class StockMarket implements Stock
{
    private List<Observer> observers;
    private double price;
    public StockMarket()
    {
        observers = new ArrayList<>();
    }
    public void register(Observer o)
    {
        observers.add(o);
    }
    public void deregister(Observer o)
    {
        observers.remove(o);
    }
    public void Notify()
    {
        for (Observer observer : observers)
        {
            observer.update(price);
        }
    }
    public void setPrice(double price)
    {
        this.price = price;
        Notify();
    }
}