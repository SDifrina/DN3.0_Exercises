import java.util.*;
public class Inventory
{
    private Map<String, Product> products;
    public Inventory()
    {
        products = new HashMap<>();
    }
    public void addProduct(Product product)
    {
        products.put(product.getProductId(), product);
    }
    public void updateProduct(String productId, Product updatedProduct)
    {
        if (products.containsKey(productId))
        {
            products.put(productId, updatedProduct);
        }
        else
        {
            System.out.println("Product not found!");
        }
    }
    public void deleteProduct(String productId)
    {
        if (products.remove(productId) == null)
        {
            System.out.println("Product not found!");
        }
    }
    public void displayAllProducts()
    {
        if(products.isEmpty())
        {
            System.out.println("No Product in Inventory");
        }
        for (Product product : products.values())
        {
            System.out.println(product);
        }
    }
    public static void main(String[] args)
    {
        Inventory inventory = new Inventory();
        Scanner sc = new Scanner(System.in);
        while (true)
        {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Display All Products");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice)
            {
                case 1:
                    System.out.print("Enter Product ID: ");
                    String addProductId = sc.nextLine();
                    System.out.print("Enter Product Name: ");
                    String addProductName = sc.nextLine();
                    System.out.print("Enter Quantity: ");
                    int addQuantity = sc.nextInt();
                    System.out.print("Enter Price: ");
                    double addPrice = sc.nextDouble();
                    sc.nextLine();

                    Product newProduct = new Product(addProductId, addProductName, addQuantity, addPrice);
                    inventory.addProduct(newProduct);
                    break;
                case 2:
                    System.out.print("Enter Product ID to update: ");
                    String updateProductId = sc.nextLine();
                    if (inventory.products.containsKey(updateProductId))
                    {
                        System.out.print("Enter new Product Name: ");
                        String updateProductName = sc.nextLine();
                        System.out.print("Enter new Quantity: ");
                        int updateQuantity = sc.nextInt();
                        System.out.print("Enter new Price: ");
                        double updatePrice = sc.nextDouble();
                        sc.nextLine();

                        Product updatedProduct = new Product(updateProductId, updateProductName, updateQuantity, updatePrice);
                        inventory.updateProduct(updateProductId, updatedProduct);
                    }
                    else
                    {
                        System.out.println("Product not found!");
                    }
                    break;
                case 3:
                    System.out.print("Enter Product ID to delete: ");
                    String deleteProductId = sc.nextLine();
                    inventory.deleteProduct(deleteProductId);
                    break;
                case 4:
                    inventory.displayAllProducts();
                    break;
                case 5:
                    System.out.println("Closing Inventory.");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
}
