import java.util.*;
public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        TaskLinkedList taskList = new TaskLinkedList();
        while (true)
        {
            System.out.println("\nTask Management System");
            System.out.println("1. Add Task");
            System.out.println("2. Search Task");
            System.out.println("3. Traverse Tasks");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice)
            {
                case 1:
                    System.out.print("Enter Task ID: ");
                    String taskId = sc.nextLine();
                    System.out.print("Enter Task Name: ");
                    String taskName = sc.nextLine();
                    System.out.print("Enter Status: ");
                    String status = sc.nextLine();

                    Task newTask = new Task(taskId, taskName, status);
                    taskList.addTask(newTask);
                    break;
                case 2:
                    System.out.print("Enter Task ID to search: ");
                    String searchId = sc.nextLine();
                    Task foundTask = taskList.searchTaskById(searchId);
                    System.out.println(foundTask != null ? foundTask : "Task not found.");
                    break;
                case 3:
                    System.out.println("List of all tasks:");
                    taskList.traverseTasks();
                    break;
                case 4:
                    System.out.print("Enter Task ID to delete: ");
                    String deleteId = sc.nextLine();
                    taskList.deleteTaskById(deleteId);
                    break;
                case 5:
                    System.out.println("Closing Task Management System");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
}
