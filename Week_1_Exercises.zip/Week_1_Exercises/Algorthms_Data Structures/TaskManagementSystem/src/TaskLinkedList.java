public class TaskLinkedList
{
    private Node head;
    public TaskLinkedList()
    {
        head = null;
    }
    public void addTask(Task task)
    {
        Node newNode = new Node(task);
        if (head == null)
        {
            head = newNode;
        }
        else
        {
            Node temp = head;
            while (temp.next != null)
            {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        System.out.println("Task added successfully!");
    }
    public Task searchTaskById(String taskId)
    {
        Node temp = head;
        while (temp != null)
        {
            if (temp.task.getTaskId().equals(taskId))
            {
                return temp.task;
            }
            temp = temp.next;
        }
        return null;
    }
    public void traverseTasks()
    {
        if (head == null)
        {
            System.out.println("No tasks to display.");
            return;
        }
        Node temp = head;
        while (temp != null)
        {
            System.out.println(temp.task);
            temp = temp.next;
        }
    }
    public void deleteTaskById(String taskId)
    {
        if (head == null)
        {
            System.out.println("No tasks to delete.");
            return;
        }
        if (head.task.getTaskId().equals(taskId))
        {
            head = head.next;
            System.out.println("Task deleted successfully!");
            return;
        }
        Node temp = head;
        while (temp.next != null && !temp.next.task.getTaskId().equals(taskId))
        {
            temp = temp.next;
        }
        if (temp.next == null)
        {
            System.out.println("Task not found.");
            return;
        }
        temp.next = temp.next.next;
        System.out.println("Task deleted successfully!");
    }
}
