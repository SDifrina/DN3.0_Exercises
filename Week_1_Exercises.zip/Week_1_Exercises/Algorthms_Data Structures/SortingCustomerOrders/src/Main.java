public class Main
{
    public static void main(String[] args)
    {
        Order[] orders = {
                new Order("O1", "Sheeba", 290.50),
                new Order("O2", "Derin", 150.75),
                new Order("O3", "Shajin", 460.),
                new Order("O4", "David", 370.20),
                new Order("O5", "Bhuvana", 120.40)
        };
        System.out.println("Orders before sorting:");
        for (Order order : orders)
        {
            System.out.println(order);
        }
        BubbleSort.sortOrdersByPrice(orders);
        System.out.println("\nOrders after Bubble Sort by total price:");
        for (Order order : orders)
        {
            System.out.println(order);
        }

        Order[] quickSortOrders = {
                new Order("QO1", "Padmavathi", 300.50),
                new Order("QO2", "Grace", 250.75),
                new Order("QO3", "Charlie", 455.),
                new Order("QO4", "Vaishnavi", 1.20),
                new Order("QO5", "Divina", 150.40)
        };
        System.out.println("\nOrders before sorting:");
        for (Order order : quickSortOrders)
        {
            System.out.println(order);
        }
        QuickSort.sortOrdersByPrice(quickSortOrders);
        System.out.println("\nOrders after Quick Sort by total price:");
        for (Order order : quickSortOrders)
        {
            System.out.println(order);
        }
    }
}
