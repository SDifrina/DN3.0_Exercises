import java.util.*;
public class Main
{
    public static void main(String[] args)
    {
        LibraryManagementSystem library = new LibraryManagementSystem(10);
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add Book");
            System.out.println("2. Search Book by Title (Linear Search)");
            System.out.println("3. Search Book by Title (Binary Search)");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice)
            {
                case 1:
                    System.out.print("Enter Book ID: ");
                    String bookId = sc.nextLine();
                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter Author: ");
                    String author = sc.nextLine();

                    Book newBook = new Book(bookId, title, author);
                    library.addBook(newBook);
                    break;
                case 2:
                    System.out.print("Enter the title of the book to search (Linear Search): ");
                    String searchTitle = sc.nextLine();
                    Book[] foundBooks = library.linearSearchByTitle(searchTitle);
                    if (foundBooks != null)
                    {
                        System.out.println("Books found:");
                        for (Book book : foundBooks)
                        {
                            if (book != null)
                            {
                                System.out.println(book);
                            }
                        }
                    }
                    else
                    {
                        System.out.println("Book not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter the title of the book to search (Binary Search): ");
                    searchTitle = sc.nextLine();
                    Book foundBook = library.binarySearchByTitle(searchTitle);
                    if (foundBook != null)
                    {
                        System.out.println("Book found:");
                        System.out.println(foundBook);
                    }
                    else
                    {
                        System.out.println("Book not found.");
                    }
                    break;
                case 4:
                    System.out.println("Closing Library Management System.");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
}
