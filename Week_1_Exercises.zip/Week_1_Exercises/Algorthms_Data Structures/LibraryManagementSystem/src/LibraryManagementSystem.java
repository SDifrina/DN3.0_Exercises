public class LibraryManagementSystem 
{
    private Book[] books;
    private int no;
    public LibraryManagementSystem(int num)
    {
        books = new Book[num];
        no = 0;
    }
    public void addBook(Book book)
    {
        if (no < books.length)
        {
            books[no++] = book;
            System.out.println("Book added successfully!");
        }
        else
        {
            System.out.println("Library is full. Cannot add more books.");
        }
    }
    public Book[] linearSearchByTitle(String title)
    {
        Book[] results = new Book[no];
        int resultno = 0;
        for (int i = 0; i < no; i++)
        {
            if (books[i].getTitle().equalsIgnoreCase(title))
            {
                results[resultno++] = books[i];
            }
        }
        return resultno == 0 ? null : results;
    }
    public Book binarySearchByTitle(String title)
    {
        int low = 0;
        int high = no - 1;
        while (low <= high)
        {
            int mid = low + (high - low) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0)
            {
                return books[mid];
            }
            else if (comparison < 0)
            {
                low = mid + 1;
            }
            else
            {
                high = mid - 1;
            }
        }
        return null;
    }
}
