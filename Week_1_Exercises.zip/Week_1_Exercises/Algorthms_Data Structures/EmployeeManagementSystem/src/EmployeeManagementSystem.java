import java.util.*;
public class EmployeeManagementSystem 
{
    private Employee[] employees;
    private int no;
    public EmployeeManagementSystem(int num) 
    {
        employees = new Employee[num];
        no = 0;
    }
    public void addEmployee(Employee employee) 
    {
        if (no < employees.length) 
        {
            employees[no++] = employee;
            System.out.println("Employee added successfully!");
        } 
        else 
        {
            System.out.println("Employee list is full. Cannot add more employees.");
        }
    }
    public Employee searchEmployeeById(String employeeId) 
    {
        for (Employee employee : employees) 
        {
            if (employee != null && employee.getEmployeeId().equals(employeeId)) 
            {
                return employee;
            }
        }
        return null;
    }
    public void traverseEmployees() 
    {
        if (no == 0) 
        {
            System.out.println("No employees to display.");
            return;
        }
        for (int i = 0; i < no; i++) 
        {
            System.out.println(employees[i]);
        }
    }
    public void deleteEmployeeById(String employeeId) 
    {
        int index = -1;
        for (int i = 0; i < no; i++) 
        {
            if (employees[i] != null && employees[i].getEmployeeId().equals(employeeId)) {
                index = i;
                break;
            }
        }
        if (index == -1) 
        {
            System.out.println("Employee not found.");
            return;
        }
        for (int i = index; i < no - 1; i++) 
        {
            employees[i] = employees[i + 1];
        }
        employees[no - 1] = null;
        no--;
        System.out.println("Employee deleted successfully!");
    }
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        EmployeeManagementSystem emp = new EmployeeManagementSystem(10);

        while (true)
        {
            System.out.println("\nEmployee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. Search Employee");
            System.out.println("3. Traverse Employees");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice)
            {
                case 1:
                    System.out.print("Enter Employee ID: ");
                    String empId = sc.nextLine();
                    System.out.print("Enter Employee Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Position: ");
                    String position = sc.nextLine();
                    System.out.print("Enter Salary: ");
                    double salary = sc.nextDouble();
                    sc.nextLine();

                    Employee newEmployee = new Employee(empId, name, position, salary);
                    emp.addEmployee(newEmployee);
                    break;
                case 2:
                    System.out.print("Enter Employee ID to search: ");
                    String searchId = sc.nextLine();
                    Employee foundEmployee = emp.searchEmployeeById(searchId);
                    System.out.println(foundEmployee != null ? foundEmployee : "Employee not found.");
                    break;
                case 3:
                    System.out.println("List of all employees:");
                    emp.traverseEmployees();
                    break;
                case 4:
                    System.out.print("Enter Employee ID to delete: ");
                    String deleteId = sc.nextLine();
                    emp.deleteEmployeeById(deleteId);
                    break;
                case 5:
                    System.out.println("Closing Employee Management System");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
}
