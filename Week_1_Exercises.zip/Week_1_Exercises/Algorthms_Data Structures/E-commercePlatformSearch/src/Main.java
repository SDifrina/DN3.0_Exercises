import java.util.*;
public class Main
{
    public static void main(String[] args)
    {
        Product[] products = {
                new Product("P001", "Laptop", "Electronics"),
                new Product("P002", "Tablet", "Electronics"),
                new Product("P003", "Keyboard", "Accessories"),
                new Product("P004", "Desk Chair", "Furniture"),
                new Product("P005", "Notebook", "Stationery"),
                new Product("P006", "Pen", "Stationery"),
                new Product("P007", "Backpack", "Bags")
        };
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Product name to search:");
        String searchName= sc.nextLine();

        Product found = LinearSearch.linearSearchByName(products, searchName);
        System.out.println("Linear Search Result: " + (found != null ? found : "Product not found"));

        found = BinarySearch.binarySearchByName(products, searchName);
        System.out.println("Binary Search Result: " + (found != null ? found : "Product not found"));
    }
}
