public class LinearSearch
{
    public static Product linearSearchByName(Product[] products, String name)
    {
        for (Product product : products)
        {
            if (product.getProductName().equalsIgnoreCase(name))
            {
                return product;
            }
        }
        return null;
    }
}
