import java.util.*;
public class FinancialForecasting
{
    public static double calculateFutureValue(double[] pastValues, int targetPeriod, double[] values)
    {
        if (values[targetPeriod] != 0)
        {
            return values[targetPeriod];
        }
        if (targetPeriod < pastValues.length)
        {
            return pastValues[targetPeriod];
        }
        double previousValue = calculateFutureValue(pastValues, targetPeriod - 1, values);
        double priorValue = calculateFutureValue(pastValues, targetPeriod - 2, values);

        double growthRate = (previousValue - priorValue) / priorValue;
        values[targetPeriod] = previousValue * (1 + growthRate);
        return values[targetPeriod];
    }
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of past data points: ");
        int num = sc.nextInt();
        double[] pastValues = new double[num];
        System.out.println("Enter the past values:");
        for (int i = 0; i < num; i++)
        {
            pastValues[i] = sc.nextDouble();
        }
        System.out.print("Enter the number of periods to forecast: ");
        int forecastPeriods = sc.nextInt();
        double[] values = new double[num + forecastPeriods];
        double futureValue = calculateFutureValue(pastValues, num + forecastPeriods - 1, values);
        System.out.printf("The future value after %d periods is: %.2f%n", forecastPeriods, futureValue);
    }
}
