package com.bookstore.service;
import com.bookstore.model.Customer;
import com.bookstore.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class CustomerService 
{
    @Autowired
    private CustomerRepository customerRepository;

    public List<Customer> findAll() 
    {
        return customerRepository.findAll();
    }

    public Optional<Customer> findById(Long id) 
    {
        return customerRepository.findById(id);
    }

    public Customer save(Customer customer) 
    {
        return customerRepository.save(customer);
    }

    public void deleteById(Long id) 
    {
        customerRepository.deleteById(id);
    }
}