package com.bookstore.service;

import com.bookstore.metrics.CustomMetrics;
import com.bookstore.model.Book;
import com.bookstore.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private CustomMetrics customMetrics;

    public Book saveBook(Book book) {
        Book savedBook = bookRepository.save(book);
        customMetrics.incrementBookCreationCounter();
        return savedBook;
    }

    public double calculateAverageBookPrice() {
        List<Book> books = bookRepository.findAll();
        double averagePrice = books.stream().mapToDouble(Book::getPrice).average().orElse(0.0);
        customMetrics.updateAverageBookPrice(averagePrice);
        return averagePrice;
    }
}
