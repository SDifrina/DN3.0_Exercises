package com.bookstore.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class CustomMetrics {

    private final MeterRegistry meterRegistry;

    public CustomMetrics(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @PostConstruct
    public void registerMetrics() {
        meterRegistry.counter("custom.book.created").increment();
        meterRegistry.gauge("custom.book.price.average", 100.0);
    }

    public void incrementBookCreationCounter() {
        meterRegistry.counter("custom.book.created").increment();
    }

    public void updateAverageBookPrice(double price) {
        meterRegistry.gauge("custom.book.price.average", price);
    }
}
