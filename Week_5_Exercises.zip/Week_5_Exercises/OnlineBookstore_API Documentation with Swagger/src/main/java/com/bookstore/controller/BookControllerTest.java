package com.bookstore.controller;

import com.bookstore.model.Book;
import com.bookstore.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.*;
import java.util.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
@WebMvcTest(BookController.class)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private BookService bookService;

    @InjectMocks
    private BookController bookController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void getAllBooks_success() throws Exception {
        Book book = new Book(1L, "Test Book", "Author", 9.99);
        when(bookService.getAllBooks()).thenReturn(Arrays.asList(book));

        mockMvc.perform(MockMvcRequestBuilders.get("/books").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(jsonPath("$[0].title").value("Test Book"));
    }

    @Test
    public void getBookById_success() throws Exception {
        Book book = new Book(1L, "Test Book", "Author", 9.99);
        when(bookService.getBookById(1L)).thenReturn(book);

        mockMvc.perform(MockMvcRequestBuilders.get("/books/1").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(jsonPath("$.title").value("Test Book"));
    }

    @Test
    public void createBook_success() throws Exception {
        Book book = new Book(1L, "Test Book", "Author", 9.99);
        when(bookService.createBook(any(Book.class))).thenReturn(book);

        mockMvc.perform(MockMvcRequestBuilders.post("/books").contentType(MediaType.APPLICATION_JSON).content("{\"title\":\"Test Book\",\"author\":\"Author\",\"price\":9.99}")).andExpect(status().isOk()).andExpect(jsonPath("$.title").value("Test Book"));
    }

    @Test
    public void updateBook_success() throws Exception {
        Book book = new Book(1L, "Updated Book", "Author", 9.99);
        when(bookService.updateBook(any(Long.class), any(Book.class))).thenReturn(book);

        mockMvc.perform(MockMvcRequestBuilders.put("/books/1").contentType(MediaType.APPLICATION_JSON).content("{\"title\":\"Updated Book\",\"author\":\"Author\",\"price\":9.99}")).andExpect(status().isOk()).andExpect(jsonPath("$.title").value("Updated Book"));
    }

    @Test
    public void deleteBook_success() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/books/1").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isNoContent());
    }
}
