package com.emp.model.primary;

import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Formula;
import jakarta.persistence.*;
@Entity
@Table(name = "employees")
@BatchSize(size = 10)
public class Employee 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    @Formula("(SELECT count(*) FROM projects WHERE employee_id = id)")
    private Integer projectCount;

    public Long getId() 
    {
        return id;
    }

    public void setId(Long id) 
    {
        this.id = id;
    }

    public String getName() 
    {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    public String getEmail() 
    {
        return email;
    }

    public void setEmail(String email) 
    {
        this.email = email;
    }

    public Integer getProjectCount() 
    {
        return projectCount;
    }

    public void setProjectCount(Integer projectCount) 
    {
        this.projectCount = projectCount;
    }
}
