package com.emp.repository;
import com.emp.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.*;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> 
{
    Page<Employee> findByNameContaining(String name, Pageable pageable);
    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:domain%")
    Page<Employee> findEmployeesByEmailDomain(String domain, Pageable pageable);
    @Query("SELECT e FROM Employee e WHERE e.department.id = :departmentId")
    Page<Employee> findEmployeesByDepartmentId(Long departmentId, Pageable pageable); 
}