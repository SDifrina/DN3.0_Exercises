package com.emp.repository;
import com.emp.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> 
{
    Optional<Department> findByNameContaining(String name);
    @Query("SELECT d FROM Department d WHERE d.name LIKE %:name%")
    Optional<Department> findDepartmentByName(String name); 
}