package com.emp.repository;
import com.emp.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> 
{
    List<Employee> findByNameContaining(String name); 
    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:domain%")
    List<Employee> findEmployeesByEmailDomain(String domain); 
    @Query("SELECT e FROM Employee e WHERE e.department.id = :departmentId")
    List<Employee> findEmployeesByDepartmentId(Long departmentId);
}