package com.emp.service;
import com.emp.model.Employee;
import com.emp.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class EmployeeService 
{
    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getEmployeesByName(String name) 
    {
        return employeeRepository.findByNameContaining(name);
    }

    public List<Employee> getEmployeesByEmailDomain(String domain) 
    {
        return employeeRepository.findEmployeesByEmailDomain(domain);
    }

    public List<Employee> getEmployeesByDepartment(Long departmentId) 
    {
        return employeeRepository.findEmployeesByDepartmentId(departmentId);
    }

    public Optional<Employee> getEmployeeById(Long id) 
    {
        return employeeRepository.findById(id);
    }

    public Employee saveEmployee(Employee employee) 
    {
        return employeeRepository.save(employee);
    }

    public void deleteEmployee(Long id) 
    {
        employeeRepository.deleteById(id);
    }
}
