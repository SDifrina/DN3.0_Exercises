package com.emp.model;
import lombok.Data;
import jakarta.persistence.*;
import java.util.*;
@Entity
@Table(name = "departments")
@Data
public class Department 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToMany(mappedBy = "department", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Employee> employees;
}

