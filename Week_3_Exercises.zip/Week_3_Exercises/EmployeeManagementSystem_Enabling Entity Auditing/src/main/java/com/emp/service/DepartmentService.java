package com.emp.service;
import com.emp.model.Department;
import com.emp.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class DepartmentService 
{
    @Autowired
    private DepartmentRepository departmentRepository;

    public Optional<Department> getDepartmentByName(String name) 
    {
        return departmentRepository.findDepartmentByName(name);
    }

    public Optional<Department> getDepartmentById(Long id) 
    {
        return departmentRepository.findById(id);
    }

    public Department saveDepartment(Department department) 
    {
        return departmentRepository.save(department);
    }

    public void deleteDepartment(Long id) 
    {
        departmentRepository.deleteById(id);
    }
}
