package com.emp.model;

public interface DepartmentProjection 
{
	 Long getId();
	 String getName();
}
