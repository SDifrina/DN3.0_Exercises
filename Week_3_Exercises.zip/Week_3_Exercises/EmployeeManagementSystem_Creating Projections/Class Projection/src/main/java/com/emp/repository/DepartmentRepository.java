package com.emp.repository;
import com.emp.model.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface DepartmentRepository extends JpaRepository<Department, Long> 
{
    Department findByName(String name);
    @Query("SELECT new com.emp.model.DepartmentDTO(d.id, d.name) FROM Department d WHERE d.id = :id")
    DepartmentDTO findDepartmentDTOById(@Param("id") Long id);
}
