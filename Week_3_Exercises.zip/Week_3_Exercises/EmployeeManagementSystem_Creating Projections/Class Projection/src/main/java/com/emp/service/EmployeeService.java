package com.emp.service;
import com.emp.model.Employee;
import com.emp.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import org.springframework.data.domain.*;
@Service
public class EmployeeService 
{
    @Autowired
    private EmployeeRepository employeeRepository;

    public Page<Employee> getEmployeesByName(String name, int page, int size, String sortBy) 
    {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        return employeeRepository.findByNameContaining(name, pageable);
    }

    public Page<Employee> getEmployeesByEmailDomain(String domain, int page, int size, String sortBy) 
    {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        return employeeRepository.findEmployeesByEmailDomain(domain, pageable);
    }

    public Page<Employee> getEmployeesByDepartment(Long departmentId, int page, int size, String sortBy) 
    {
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        return employeeRepository.findEmployeesByDepartmentId(departmentId, pageable);
    }

    public Optional<Employee> getEmployeeById(Long id) 
    {
        return employeeRepository.findById(id);
    }

    public Employee saveEmployee(Employee employee) 
    {
        return employeeRepository.save(employee);
    }

    public void deleteEmployee(Long id) 
    {
        employeeRepository.deleteById(id);
    }
}