package com.emp.repository.secondary;
import com.emp.model.secondary.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DepartmentRepository extends JpaRepository<Department, Long> 
{
    Department findByName(String name);
    @Query("SELECT d FROM Department d WHERE d.id = :id")
    Department findDepartmentById(@Param("id") Long id);
}
