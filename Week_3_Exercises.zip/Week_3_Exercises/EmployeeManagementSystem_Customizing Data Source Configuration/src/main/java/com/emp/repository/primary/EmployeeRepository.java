package com.emp.repository.primary;
import com.emp.model.primary.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface EmployeeRepository extends JpaRepository<Employee, Long> 
{
    Page<Employee> findByNameContaining(String name, Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.email LIKE %:domain%")
    Page<Employee> findEmployeesByEmailDomain(@Param("domain") String domain, Pageable pageable);
}
