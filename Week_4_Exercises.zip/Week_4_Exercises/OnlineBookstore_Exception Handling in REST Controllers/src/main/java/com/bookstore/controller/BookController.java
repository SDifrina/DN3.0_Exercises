package com.bookstore.controller;

import com.bookstore.model.Book;
import com.bookstore.service.BookService;
import com.bookstore.exception.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController
@RequestMapping("/books")
public class BookController 
{
    @Autowired
    private BookService bookService;

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() 
    {
        List<Book> books = bookService.findAll();
        return ResponseEntity.ok(books); 
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) 
    {
        Optional<Book> book = bookService.findById(id);
        return book.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build()); // Returns 404 NOT FOUND
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) 
    public void createBook(@RequestBody Book book) 
    {
        bookService.save(book);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book) 
    {
    	if (!bookService.findById(id).isPresent()) 
    	{
            throw new ResourceNotFoundException("Book not found with ID " + id); // Throws custom exception
        }
        book.setId(id);
        Book updatedBook = bookService.save(book);
        return ResponseEntity.ok(updatedBook);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) 
    public void deleteBook(@PathVariable Long id) 
    {
    	if (!bookService.findById(id).isPresent()) 
    	{
            throw new ResourceNotFoundException("Book not found with ID " + id); // Throws custom exception
        }
        bookService.deleteById(id);
    }

    @GetMapping("/custom-header")
    public ResponseEntity<List<Book>> getBooksWithCustomHeader() 
    {
        List<Book> books = bookService.findAll();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "HeaderValue");
        return new ResponseEntity<>(books, headers, HttpStatus.OK);
    }
}
