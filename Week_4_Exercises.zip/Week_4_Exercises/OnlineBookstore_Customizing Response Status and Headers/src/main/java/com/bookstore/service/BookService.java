package com.bookstore.service;
import com.bookstore.model.Book;
import com.bookstore.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class BookService 
{
    @Autowired
    private BookRepository bookRepository;
    public List<Book> findAll() 
    {
        return bookRepository.findAll();
    }
    
    public Optional<Book> findById(Long id) 
    {
        return bookRepository.findById(id);
    }
    
    public Book save(Book book) 
    {
        return bookRepository.save(book);
    }
    
    public void deleteById(Long id) 
    {
        bookRepository.deleteById(id);
    }
    public List<Book> findByTitle(String title) 
    {
        return bookRepository.findByTitleContaining(title);
    }
    
    public List<Book> findByAuthor(String author) 
    {
        return bookRepository.findByAuthorContaining(author);
    }
    
    public List<Book> findByTitleAndAuthor(String title, String author) 
    {
        return bookRepository.findByTitleContainingAndAuthorContaining(title, author);
    }
}